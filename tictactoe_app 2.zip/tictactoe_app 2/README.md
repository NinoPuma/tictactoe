# Tic tac toe

## Realizado con vite + react

#### Componetizado y utilizado para aprender react

#### Utilización de LocalStorage para guardar el estado de la partida

#### Utilización del hook useState